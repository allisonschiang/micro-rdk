fn main() {
    chrono_tz_build::main();
}
