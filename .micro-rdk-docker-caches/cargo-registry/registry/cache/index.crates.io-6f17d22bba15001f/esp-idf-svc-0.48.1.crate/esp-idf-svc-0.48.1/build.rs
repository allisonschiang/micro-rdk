fn main() {
    embuild::espidf::sysenv::relay();
    embuild::espidf::sysenv::output(); // Only necessary for building the examples
}
