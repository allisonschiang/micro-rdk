See https://github.com/briansmith/ring.
