struct_domain_name!(DNAME, target);
