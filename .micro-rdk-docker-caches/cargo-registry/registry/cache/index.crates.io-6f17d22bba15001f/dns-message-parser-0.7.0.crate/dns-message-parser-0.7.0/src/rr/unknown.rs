struct_vec!(EID, data);

struct_vec!(NIMLOC, data);
