#[derive(num_enum::IntoPrimitive)]
#[repr(C)]
enum Numbers {
    Zero,
    One,
}

fn main() {}
