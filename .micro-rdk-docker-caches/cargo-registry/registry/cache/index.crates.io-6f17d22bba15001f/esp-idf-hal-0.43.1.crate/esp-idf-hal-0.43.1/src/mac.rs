crate::impl_peripheral!(MAC);
