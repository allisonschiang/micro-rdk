pub use embedded_io::*;

pub mod asynch {
    pub use embedded_io_async::*;
}
