#[derive(defmt::Format)]
struct S {
    #[defmt()]
    f: bool,
}

fn main() {}
