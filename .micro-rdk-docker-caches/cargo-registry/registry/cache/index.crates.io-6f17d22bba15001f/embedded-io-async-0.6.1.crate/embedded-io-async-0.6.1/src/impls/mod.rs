mod slice_mut;
mod slice_ref;

#[cfg(feature = "alloc")]
mod boxx;
#[cfg(feature = "alloc")]
mod vec;
