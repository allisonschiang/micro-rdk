# sdp changelog

## Unreleased

## v0.5.3

* Increased minimum support rust version to `1.60.0`.

## v0.5.2

* [#10 update deps + loosen some requirements](https://github.com/webrtc-rs/sdp/pull/10) by [@melekes](https://github.com/melekes).

## Prior to 0.5.2

Before 0.5.2 there was no changelog, previous changes are sometimes, but not always, available in the [GitHub Releases](https://github.com/webrtc-rs/sdp/releases).

