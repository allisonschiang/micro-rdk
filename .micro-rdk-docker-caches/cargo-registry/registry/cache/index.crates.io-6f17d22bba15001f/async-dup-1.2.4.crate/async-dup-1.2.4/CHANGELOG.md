# Version 1.2.4

- Use the `async-lock` crate as the locking mechanism. (#14)

# Version 1.2.3

- Remove the unnecessary `simple-mutex` dependency. (#10)

# Version 1.2.2

- Fix typos in the docs.

# Version 1.2.1

- Forbid unsafe code.

# Version 1.2.0

- Make the inner `std::sync::Arc` public.

# Version 1.1.0

- Implement `AsyncSeek` for `Arc`, `Mutex`, and `&Mutex`.

# Version 1.0.1

- Fix failing tests.

# Version 1.0.0

- Initial version
