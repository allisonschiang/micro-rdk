//! Marker types.

/// Never instantiated type.
#[derive(Debug)]
pub struct Never(());
